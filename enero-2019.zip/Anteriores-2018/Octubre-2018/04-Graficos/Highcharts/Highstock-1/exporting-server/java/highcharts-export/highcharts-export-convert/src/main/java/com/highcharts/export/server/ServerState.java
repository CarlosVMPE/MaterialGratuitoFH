package com.highcharts.export.server;


public enum ServerState {
	IDLE, DEAD, BUSY, TIMEDOUT, ACTIVE;
}