IMPORTANTE!:

Deben de correr este archivo en HTTP o HTTP... si usan el protocolo FILE, no funcionará.