Creative Stack Effects
=========

Some inspiration for interactions on item stacks for hovers, clicks, on-scroll or other. 

[Article on Codrops](http://tympanus.net/codrops/?p=18593)

[Demo](hht://tympanus.net/Development/StackEffects)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)


[© Codrops 2013](http://www.codrops.com)