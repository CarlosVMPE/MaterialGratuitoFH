v2.0.0
---
- Embed quantize into color thief file
- Strip out jQuery requirement
- Credit those who helped with edits - Nathan Spady for drag and drop support.

**Demo page and example changes**

- Don't show yellow circle buttons till images have loaded
- Add FB and Twitter buttons
- Add drag n drop support
- Make design responsive
- Touch support on demo page
